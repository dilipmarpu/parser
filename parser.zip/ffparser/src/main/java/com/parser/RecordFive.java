package com.parser;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord
public class RecordFive {
	
	@PositionalField(initialPosition = 1, finalPosition = 1)
	public String getDetailRecordId() {
		return detailRecordId;
	}
	public void setDetailRecordId(String detailRecordId) {
		this.detailRecordId = detailRecordId;
	}
	
	@PositionalField(initialPosition = 2, finalPosition = 7)
	public String getSeqTraceNum() {
		return seqTraceNum;
	}
	public void setSeqTraceNum(String seqTraceNum) {
		this.seqTraceNum = seqTraceNum;
	}
	
	@PositionalField(initialPosition = 8, finalPosition = 41)
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
	@PositionalField(initialPosition = 42, finalPosition = 76)
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	
	@PositionalField(initialPosition = 77, finalPosition = 111)
	public String getCustAddrone() {
		return custAddrone;
	}
	public void setCustAddrone(String custAddrone) {
		this.custAddrone = custAddrone;
	}
	
	
	@PositionalField(initialPosition = 112, finalPosition = 146)
	public String getCustAddrtwo() {
		return custAddrtwo;
	}
	public void setCustAddrtwo(String custAddrtwo) {
		this.custAddrtwo = custAddrtwo;
	}
	
	
	@PositionalField(initialPosition = 147, finalPosition = 181)
	public String getCustAddrthree() {
		return custAddrthree;
	}
	public void setCustAddrthree(String custAddrthree) {
		this.custAddrthree = custAddrthree;
	}
	
	
	@PositionalField(initialPosition = 182, finalPosition = 188)
	public String getChargeIndicator() {
		return chargeIndicator;
	}
	public void setChargeIndicator(String chargeIndicator) {
		this.chargeIndicator = chargeIndicator;
	}
	
	@PositionalField(initialPosition = 189, finalPosition = 189)
	public String getPaymentIndicator() {
		return paymentIndicator;
	}
	public void setPaymentIndicator(String paymentIndicator) {
		this.paymentIndicator = paymentIndicator;
	}
	
	@PositionalField(initialPosition = 190, finalPosition = 223)
	public String getRecvBnkId() {
		return recvBnkId;
	}
	public void setRecvBnkId(String recvBnkId) {
		this.recvBnkId = recvBnkId;
	}
	
	@PositionalField(initialPosition = 224, finalPosition = 258)
	public String getRecvBnkName() {
		return recvBnkName;
	}
	public void setRecvBnkName(String recvBnkName) {
		this.recvBnkName = recvBnkName;
	}
	
	@PositionalField(initialPosition = 259, finalPosition = 293)
	public String getRecvBnkAddrone() {
		return recvBnkAddrone;
	}
	public void setRecvBnkAddrone(String recvBnkAddrone) {
		this.recvBnkAddrone = recvBnkAddrone;
	}
	
	@PositionalField(initialPosition = 294, finalPosition = 328)
	public String getRecvBnkAddrtwo() {
		return recvBnkAddrtwo;
	}
	public void setRecvBnkAddrtwo(String recvBnkAddrtwo) {
		this.recvBnkAddrtwo = recvBnkAddrtwo;
	}
	
	@PositionalField(initialPosition = 329, finalPosition = 363)
	public String getRecvBnkAddrthree() {
		return recvBnkAddrthree;
	}
	public void setRecvBnkAddrthree(String recvBnkAddrthree) {
		this.recvBnkAddrthree = recvBnkAddrthree;
	}
	
	@PositionalField(initialPosition = 364, finalPosition = 403)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@PositionalField(initialPosition = 404, finalPosition = 512)
	public String getFiller() {
		return filler;
	}
	public void setFiller(String filler) {
		this.filler = filler;
	}
	private String detailRecordId;
	private String seqTraceNum;
	private String custId;
	private String custName;
	private String custAddrone;
	private String custAddrtwo;
	private String custAddrthree;
	private String chargeIndicator;
	private String paymentIndicator;
	private String recvBnkId;
	private String recvBnkName;
	private String recvBnkAddrone;
	private String recvBnkAddrtwo;
	private String recvBnkAddrthree;
	private String email;
	private String filler;

}
