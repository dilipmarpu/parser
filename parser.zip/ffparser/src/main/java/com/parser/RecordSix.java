package com.parser;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord
public class RecordSix {

	@PositionalField(initialPosition = 1, finalPosition = 1)
	public String getDetailrecordid() {
		return detailrecordid;
	}

	public void setDetailrecordid(String detailrecordid) {
		this.detailrecordid = detailrecordid;
	}
	
	
	@PositionalField(initialPosition = 2, finalPosition = 7)
	public String getSeqTraceNum() {
		return seqTraceNum;
	}

	public void setSeqTraceNum(String seqTraceNum) {
		this.seqTraceNum = seqTraceNum;
	}

	@PositionalField(initialPosition = 8, finalPosition = 8)
	public String getRecord_id() {
		return record_id;
	}

	public void setRecord_id(String record_id) {
		this.record_id = record_id;
	}

	@PositionalField(initialPosition = 9, finalPosition = 43)
	public String getRemittanceDetail1() {
		return remittanceDetail1;
	}

	public void setRemittanceDetail1(String remittanceDetail1) {
		this.remittanceDetail1 = remittanceDetail1;
	}

	@PositionalField(initialPosition = 44, finalPosition = 78)
	public String getRemittanceDetail2() {
		return remittanceDetail2;
	}

	public void setRemittanceDetail2(String remittanceDetail2) {
		this.remittanceDetail2 = remittanceDetail2;
	}

	@PositionalField(initialPosition = 79, finalPosition = 113)
	public String getRemittanceDetail3() {
		return remittanceDetail3;
	}

	public void setRemittanceDetail3(String remittanceDetail3) {
		this.remittanceDetail3 = remittanceDetail3;
	}

	@PositionalField(initialPosition = 114, finalPosition = 148)
	public String getRemittanceDetail4() {
		return remittanceDetail4;
	}

	public void setRemittanceDetail4(String remittanceDetail4) {
		this.remittanceDetail4 = remittanceDetail4;
	}

	@PositionalField(initialPosition = 149, finalPosition = 183)
	public String getRemittanceDetail5() {
		return remittanceDetail5;
	}

	public void setRemittanceDetail5(String remittanceDetail5) {
		this.remittanceDetail5 = remittanceDetail5;
	}

	@PositionalField(initialPosition = 184, finalPosition = 218)
	public String getRemittanceDetail6() {
		return remittanceDetail6;
	}

	public void setRemittanceDetail6(String remittanceDetail6) {
		this.remittanceDetail6 = remittanceDetail6;
	}

	@PositionalField(initialPosition = 219, finalPosition = 253)
	public String getRemittanceDetail7() {
		return remittanceDetail7;
	}

	public void setRemittanceDetail7(String remittanceDetail7) {
		this.remittanceDetail7 = remittanceDetail7;
	}

	@PositionalField(initialPosition = 254, finalPosition = 288)
	public String getRemittanceDetail8() {
		return remittanceDetail8;
	}

	public void setRemittanceDetail8(String remittanceDetail8) {
		this.remittanceDetail8 = remittanceDetail8;
	}

	
	@PositionalField(initialPosition = 289, finalPosition = 322)
	public String getRemittanceDetail9() {
		return remittanceDetail9;
	}

	public void setRemittanceDetail9(String remittanceDetail9) {
		this.remittanceDetail9 = remittanceDetail9;
	}

	@PositionalField(initialPosition = 324, finalPosition = 358)
	public String getRemittanceDetail10() {
		return remittanceDetail10;
	}

	public void setRemittanceDetail10(String remittanceDetail10) {
		this.remittanceDetail10 = remittanceDetail10;
	}

	@PositionalField(initialPosition = 359, finalPosition = 512)
	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	private String detailrecordid;
	private String seqTraceNum;
	private String record_id;
	private String remittanceDetail1;
	private String remittanceDetail2;
	private String remittanceDetail3;
	private String remittanceDetail4;
	private String remittanceDetail5;
	private String remittanceDetail6;
	private String remittanceDetail7;
	private String remittanceDetail8;
	private String remittanceDetail9;
	private String remittanceDetail10;
	
	private String filler;
	
}
