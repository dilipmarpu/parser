package com.parser;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord
public class Header {

	private String fileHeaderRecord;
	private String nameOfPayer;
	private String fileSequenceNumber;
	private String sourceCurrencyCode;
	private String clientBNY;
	private String paymentTypeDesc;
	private String fileCreationDate;
	private String fileSettlementDate;
	private String payoutIndicator;
	private String companyId;
	private String fileStatus;
	private String fileLayout;
	private String filler;
	
	@PositionalField(initialPosition = 1, finalPosition = 1)
	public String getFileHeaderRecord() {
		return fileHeaderRecord;
	}
	public void setFileHeaderRecord(String fileHeaderRecord) {
		this.fileHeaderRecord = fileHeaderRecord;
	}
	
	@PositionalField(initialPosition = 2, finalPosition = 36)
	public String getNameOfPayer() {
		return nameOfPayer;
	}
	public void setNameOfPayer(String nameOfPayer) {
		this.nameOfPayer = nameOfPayer;
	}
	
	@PositionalField(initialPosition = 37, finalPosition = 40)
	public String getFileSequenceNumber() {
		return fileSequenceNumber;
	}
	public void setFileSequenceNumber(String fileSequenceNumber) {
		this.fileSequenceNumber = fileSequenceNumber;
	}
	
	@PositionalField(initialPosition = 41, finalPosition = 43)
	public String getSourceCurrencyCode() {
		return sourceCurrencyCode;
	}
	public void setSourceCurrencyCode(String sourceCurrencyCode) {
		this.sourceCurrencyCode = sourceCurrencyCode;
	}
	
	
	@PositionalField(initialPosition = 44, finalPosition = 53)
	public String getClientBNY() {
		return clientBNY;
	}
	public void setClientBNY(String clientBNY) {
		this.clientBNY = clientBNY;
	}
	
	@PositionalField(initialPosition = 54, finalPosition = 63)
	public String getPaymentTypeDesc() {
		return paymentTypeDesc;
	}
	public void setPaymentTypeDesc(String paymentTypeDesc) {
		this.paymentTypeDesc = paymentTypeDesc;
	}
	
	
	@PositionalField(initialPosition = 64, finalPosition = 71)
	public String getFileCreationDate() {
		return fileCreationDate;
	}
	public void setFileCreationDate(String fileCreationDate) {
		this.fileCreationDate = fileCreationDate;
	}
	
	@PositionalField(initialPosition = 72, finalPosition = 79)
	public String getFileSettlementDate() {
		return fileSettlementDate;
	}
	public void setFileSettlementDate(String fileSettlementDate) {
		this.fileSettlementDate = fileSettlementDate;
	}
	
	@PositionalField(initialPosition = 80, finalPosition = 80)
	public String getPayoutIndicator() {
		return payoutIndicator;
	}
	public void setPayoutIndicator(String payoutIndicator) {
		this.payoutIndicator = payoutIndicator;
	}
	
	@PositionalField(initialPosition = 81, finalPosition = 90)
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	
	@PositionalField(initialPosition = 91, finalPosition = 120)
	public String getFileStatus() {
		return fileStatus;
	}
	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}
	
	@PositionalField(initialPosition = 121, finalPosition = 130)
	public String getFileLayout() {
		return fileLayout;
	}
	public void setFileLayout(String fileLayout) {
		this.fileLayout = fileLayout;
	}
	
	
	@PositionalField(initialPosition = 131, finalPosition = 512)
	public String getFiller() {
		return filler;
	}
	public void setFiller(String filler) {
		this.filler = filler;
	}




}