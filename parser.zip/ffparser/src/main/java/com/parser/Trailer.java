package com.parser;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord
public class Trailer {
	
	private String recordNum;
	private String numOfRecords;
	private String numOfpayments;
	private String amtSrcCurrency;
	private String totalPayoutCurrency;
	private String FileLayoutVersCtrl;
	private String Filler;

	@PositionalField(initialPosition = 1, finalPosition = 1)
	public String getRecordNum() {
		return recordNum;
	}
	public void setRecordNum(String recordNum) {
		this.recordNum = recordNum;
	}
	
	@PositionalField(initialPosition = 2, finalPosition = 11)
	public String getNumOfRecords() {
		return numOfRecords;
	}
	public void setNumOfRecords(String numOfRecords) {
		this.numOfRecords = numOfRecords;
	}
	
	
	@PositionalField(initialPosition = 12, finalPosition = 21)
	public String getNumOfpayments() {
		return numOfpayments;
	}
	public void setNumOfpayments(String numOfpayments) {
		this.numOfpayments = numOfpayments;
	}
	
	@PositionalField(initialPosition = 22, finalPosition = 36)
	public String getAmtSrcCurrency() {
		return amtSrcCurrency;
	}
	public void setAmtSrcCurrency(String amtSrcCurrency) {
		this.amtSrcCurrency = amtSrcCurrency;
	}
	
	@PositionalField(initialPosition = 37, finalPosition = 51)
	public String getTotalPayoutCurrency() {
		return totalPayoutCurrency;
	}
	public void setTotalPayoutCurrency(String totalPayoutCurrency) {
		this.totalPayoutCurrency = totalPayoutCurrency;
	}
	
	@PositionalField(initialPosition = 52, finalPosition = 61)
	public String getFileLayoutVersCtrl() {
		return FileLayoutVersCtrl;
	}
	public void setFileLayoutVersCtrl(String fileLayoutVersCtrl) {
		FileLayoutVersCtrl = fileLayoutVersCtrl;
	}
	
	
	@PositionalField(initialPosition = 62, finalPosition = 512)
	public String getFiller() {
		return Filler;
	}
	public void setFiller(String filler) {
		Filler = filler;
	}

}
