package com.parser;

import com.github.ffpojo.metadata.positional.annotation.PositionalField;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;

@PositionalRecord
public class RecordTwo {
	
	
	private String recordId;
	private String seqTraceNum;
	private String accType;
	private String recBnkIDCode;
	private String benAccNum;
	private String benName;
	
	private String benAddrone;
	private String benAddrtwo;
	private String benAddrthree;
	
	private String payerReference;
	private String srcCurrCode;
	private String instructedAmt;
	private String paymentCurrCode;
	private String isoCntryCode;
	private String paymentTypeCode;
	private String fxfactor;
	private String paySettleAmt;
	private String bnyReferenceNum;
	
	
	private String psCode1;
	private String psCode2;
	private String psCode3;
	private String psCode4;
	private String psCode5;
	private String psCode6;
	private String psCode7;
	private String psCode8;
	private String psCode9;
	private String psCode10;
	private String psCode11;
	private String psCode12;
	private String psCode13;
	private String psCode14;
	private String filler;
	
	@PositionalField(initialPosition = 1, finalPosition = 1)
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	
	@PositionalField(initialPosition = 2, finalPosition = 7)
	public String getSeqTraceNum() {
		return seqTraceNum;
	}
	public void setSeqTraceNum(String seqTraceNum) {
		this.seqTraceNum = seqTraceNum;
	}
	
	
	@PositionalField(initialPosition = 8, finalPosition = 8)
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	
	@PositionalField(initialPosition = 9, finalPosition = 23)
	public String getRecBnkIDCode() {
		return recBnkIDCode;
	}
	public void setRecBnkIDCode(String recBnkIDCode) {
		this.recBnkIDCode = recBnkIDCode;
	}
	
	
	@PositionalField(initialPosition = 24, finalPosition = 57)
	public String getBenAccNum() {
		return benAccNum;
	}
	public void setBenAccNum(String benAccNum) {
		this.benAccNum = benAccNum;
	}
	
	
	@PositionalField(initialPosition = 58, finalPosition = 92)
	public String getBenName() {
		return benName;
	}
	public void setBenName(String benName) {
		this.benName = benName;
	}
	
	@PositionalField(initialPosition = 93, finalPosition = 127)
	public String getBenAddrone() {
		return benAddrone;
	}
	public void setBenAddrone(String benAddrone) {
		this.benAddrone = benAddrone;
	}
	
	
	@PositionalField(initialPosition = 128, finalPosition = 162)
	public String getBenAddrtwo() {
		return benAddrtwo;
	}
	public void setBenAddrtwo(String benAddrtwo) {
		this.benAddrtwo = benAddrtwo;
	}
	
	
	@PositionalField(initialPosition = 163, finalPosition = 197)
	public String getBenAddrthree() {
		return benAddrthree;
	}
	public void setBenAddrthree(String benAddrthree) {
		this.benAddrthree = benAddrthree;
	}
	
	
	@PositionalField(initialPosition = 198, finalPosition = 213)
	public String getPayerReference() {
		return payerReference;
	}
	public void setPayerReference(String payerReference) {
		this.payerReference = payerReference;
	}
	
	
	@PositionalField(initialPosition = 214, finalPosition = 216)
	public String getSrcCurrCode() {
		return srcCurrCode;
	}
	public void setSrcCurrCode(String srcCurrCode) {
		this.srcCurrCode = srcCurrCode;
	}
	
	
	@PositionalField(initialPosition = 217, finalPosition = 231)
	public String getInstructedAmt() {
		return instructedAmt;
	}
	public void setInstructedAmt(String instructedAmt) {
		this.instructedAmt = instructedAmt;
	}
	
	
	@PositionalField(initialPosition = 232, finalPosition = 234)
	public String getPaymentCurrCode() {
		return paymentCurrCode;
	}
	public void setPaymentCurrCode(String paymentCurrCode) {
		this.paymentCurrCode = paymentCurrCode;
	}
	
	
	@PositionalField(initialPosition = 235, finalPosition = 236)
	public String getIsoCntryCode() {
		return isoCntryCode;
	}
	public void setIsoCntryCode(String isoCntryCode) {
		this.isoCntryCode = isoCntryCode;
	}
	
	@PositionalField(initialPosition = 237, finalPosition = 239)
	public String getPaymentTypeCode() {
		return paymentTypeCode;
	}
	public void setPaymentTypeCode(String paymentTypeCode) {
		this.paymentTypeCode = paymentTypeCode;
	}
	
	@PositionalField(initialPosition = 240, finalPosition = 251)
	public String getFxfactor() {
		return fxfactor;
	}
	public void setFxfactor(String fxfactor) {
		this.fxfactor = fxfactor;
	}
	
	@PositionalField(initialPosition = 252, finalPosition = 266)
	public String getPaySettleAmt() {
		return paySettleAmt;
	}
	public void setPaySettleAmt(String paySettleAmt) {
		this.paySettleAmt = paySettleAmt;
	}
	
	
	@PositionalField(initialPosition = 267, finalPosition = 282)
	public String getBnyReferenceNum() {
		return bnyReferenceNum;
	}
	public void setBnyReferenceNum(String bnyReferenceNum) {
		this.bnyReferenceNum = bnyReferenceNum;
	}
	
	
	@PositionalField(initialPosition = 283, finalPosition = 298)
	public String getPsCode1() {
		return psCode1;
	}
	public void setPsCode1(String psCode1) {
		this.psCode1 = psCode1;
	}
	
	
	@PositionalField(initialPosition = 299, finalPosition = 314)
	public String getPsCode2() {
		return psCode2;
	}
	public void setPsCode2(String psCode2) {
		this.psCode2 = psCode2;
	}
	
	@PositionalField(initialPosition = 315, finalPosition = 330)
	public String getPsCode3() {
		return psCode3;
	}
	public void setPsCode3(String psCode3) {
		this.psCode3 = psCode3;
	}
	
	
	@PositionalField(initialPosition = 331, finalPosition = 346)
	public String getPsCode4() {
		return psCode4;
	}
	public void setPsCode4(String psCode4) {
		this.psCode4 = psCode4;
	}
	
	
	@PositionalField(initialPosition = 347, finalPosition = 362)
	public String getPsCode5() {
		return psCode5;
	}
	public void setPsCode5(String psCode5) {
		this.psCode5 = psCode5;
	}
	
	
	@PositionalField(initialPosition = 363, finalPosition = 378)
	public String getPsCode6() {
		return psCode6;
	}
	public void setPsCode6(String psCode6) {
		this.psCode6 = psCode6;
	}
	
	
	@PositionalField(initialPosition = 379, finalPosition = 394)
	public String getPsCode7() {
		return psCode7;
	}
	public void setPsCode7(String psCode7) {
		this.psCode7 = psCode7;
	}
	
	@PositionalField(initialPosition = 395, finalPosition = 410)
	public String getPsCode8() {
		return psCode8;
	}
	public void setPsCode8(String psCode8) {
		this.psCode8 = psCode8;
	}
	
	@PositionalField(initialPosition = 411, finalPosition = 426)
	public String getPsCode9() {
		return psCode9;
	}
	public void setPsCode9(String psCode9) {
		this.psCode9 = psCode9;
	}
	
	@PositionalField(initialPosition = 427, finalPosition = 442)
	public String getPsCode10() {
		return psCode10;
	}
	public void setPsCode10(String psCode10) {
		this.psCode10 = psCode10;
	}
	
	
	@PositionalField(initialPosition = 443, finalPosition = 458)
	public String getPsCode11() {
		return psCode11;
	}
	public void setPsCode11(String psCode11) {
		this.psCode11 = psCode11;
	}
	
	
	@PositionalField(initialPosition = 459, finalPosition = 474)
	public String getPsCode12() {
		return psCode12;
	}
	public void setPsCode12(String psCode12) {
		this.psCode12 = psCode12;
	}
	
	
	@PositionalField(initialPosition = 475, finalPosition = 490)
	public String getPsCode13() {
		return psCode13;
	}
	public void setPsCode13(String psCode13) {
		this.psCode13 = psCode13;
	}
	
	
	@PositionalField(initialPosition = 491, finalPosition = 506)
	public String getPsCode14() {
		return psCode14;
	}
	public void setPsCode14(String psCode14) {
		this.psCode14 = psCode14;
	}
	
	
	
	@PositionalField(initialPosition = 507, finalPosition = 512)
	public String getFiller() {
		return filler;
	}
	public void setFiller(String filler) {
		this.filler = filler;
	}


}
