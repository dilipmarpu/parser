package com.parser;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.github.ffpojo.exception.FFPojoException;
import com.github.ffpojo.file.reader.FlatFileReader;
import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
import com.github.ffpojo.file.reader.InputStreamFlatFileReader;
import com.github.ffpojo.file.reader.RecordType;

public class SimplePositionalRecordParsingExample {
	private static final String INPUT_TXT_RESOURCE_CLASSPATH = "input.txt";
	
	public static void main(String[] args) {
		SimplePositionalRecordParsingExample example = new SimplePositionalRecordParsingExample();
		try {
		//	System.out.println("Making POJO from file system TXT FILE...");
			example.readCustomersFromText();

			System.out.println("END !");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (FFPojoException e) {
			e.printStackTrace();
		}
	}
	public void readCustomersFromText() throws IOException, FFPojoException {
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream(INPUT_TXT_RESOURCE_CLASSPATH);

		FlatFileReaderDefinition ffDefinition = new FlatFileReaderDefinition(RecordTwo.class);
		ffDefinition.setHeader(Header.class);
		FlatFileReader ffReader = new InputStreamFlatFileReader(inputStream, ffDefinition);
		List<RecordTwo> datalist = new ArrayList<RecordTwo>();
		List<RecordSix> recordSixlist = new ArrayList<RecordSix>();
		List<RecordFive> recordFivelist = new ArrayList<RecordFive>();
		
		for (Object record : ffReader) {
			RecordType recordType = ffReader.getRecordType();
			if (recordType == RecordType.HEADER) {
				Header header = (Header)record;
				System.out.println("---------------------------------------------------------");
				System.out.println("Header");
				System.out.println("---------------------------------------------------------");
				System.out.println(" ClientBNY : "+header.getClientBNY());
				System.out.println(" CompanyId : "+header.getCompanyId());
				System.out.println(" FileCreationDate : "+header.getFileCreationDate());
				System.out.println(" FileHeaderRecord : "+header.getFileHeaderRecord());
				System.out.println(" FileLayout : "+header.getFileLayout());
				System.out.println(" FileSequenceNumber : "+header.getFileSequenceNumber());
				System.out.println(" FileSettlementDate : "+header.getFileSettlementDate());
				System.out.println(" FileStatus : "+header.getFileStatus());
				System.out.println(" Filler : "+header.getFiller());
				System.out.println(" NameOfPayer : "+header.getNameOfPayer());
				System.out.println(" PaymentTypeDesc : "+header.getPaymentTypeDesc());
				System.out.println(" PayoutIndicator : "+header.getPayoutIndicator());
				System.out.println(" SourceCurrencyCode : "+header.getSourceCurrencyCode());
				
				
				System.out.println("---------------------------------------------------------");
			} else if (recordType == RecordType.BODY) {
				RecordTwo rt = (RecordTwo)record;
				if(rt.getRecordId().startsWith("2")) {
					datalist.add(rt);
				}
			} 
		}
		
		System.out.println("Size of rctwo "+datalist.size());
		for(RecordTwo rec : datalist) {
			System.out.println("  RecordId : "+rec.getRecordId());
			System.out.println("  AccType : "+rec.getAccType());
			System.out.println("  AccNum : "+rec.getBenAccNum());
			System.out.println("  BenAddrone : "+rec.getBenAddrone());
			System.out.println("  BenAddrtwo : "+rec.getBenAddrtwo());
			System.out.println("  BenAddrthree : "+rec.getBenAddrthree());
			
			System.out.println("  BenName : "+rec.getBenName());
			System.out.println("  BnyReferenceNum : "+rec.getBnyReferenceNum());
			System.out.println("  Filler : "+rec.getFiller());
			System.out.println("  Fxfactor : "+rec.getFxfactor());
			
			
			System.out.println("  InstructedAmt : "+rec.getInstructedAmt());
			System.out.println("  IsoCntryCode : "+rec.getIsoCntryCode());
			System.out.println("  PayerReference : "+rec.getPayerReference());
			System.out.println("  PaymentCurrCode : "+rec.getPaymentCurrCode());
			System.out.println("  PaymentTypeCode : "+rec.getPaymentTypeCode());
			
			
			System.out.println("  PaySettleAmt : "+rec.getPaySettleAmt());
			System.out.println("  PsCode1 : "+rec.getPsCode1());
			System.out.println("  PsCode2 : "+rec.getPsCode2());
			System.out.println("  PsCode3 : "+rec.getPsCode3());
			System.out.println("  PsCode4 : "+rec.getPsCode4());
			
			System.out.println("  PsCode5 : "+rec.getPsCode5());
			System.out.println("  PsCode6 : "+rec.getPsCode6());
			System.out.println("  PsCode7 : "+rec.getPsCode7());
			System.out.println("  PsCode8 : "+rec.getPsCode8());
			System.out.println("  PsCode9 : "+rec.getPsCode9());
			
			System.out.println("  PsCode10 : "+rec.getPsCode10());
			System.out.println("  PsCode11 : "+rec.getPsCode11());
			System.out.println("  PsCode12 : "+rec.getPsCode12());
			System.out.println("  PsCode13 : "+rec.getPsCode13());
			System.out.println("  PsCode14 : "+rec.getPsCode14());
			
			System.out.println("  RecBnkIDCode : "+rec.getRecBnkIDCode());
			System.out.println("  SeqTraceNum : "+rec.getSeqTraceNum());
			System.out.println("  SrcCurrCode : "+rec.getSrcCurrCode());
			
			
			
		}
		
/* Detail Record 5*/
		
		InputStream inputStreamfive = getClass().getClassLoader().getResourceAsStream(INPUT_TXT_RESOURCE_CLASSPATH);		
		FlatFileReaderDefinition ffDefinitionfive = new FlatFileReaderDefinition(RecordFive.class);
		ffDefinition.setHeader(Header.class);
		FlatFileReader ffReaderfive = new InputStreamFlatFileReader(inputStreamfive, ffDefinitionfive);
		
		for(Object record :  ffReaderfive) {
			RecordType recordType = ffReaderfive.getRecordType();
				if (recordType == RecordType.BODY) {
				RecordFive rt = (RecordFive)record;
				if(rt.getDetailRecordId().startsWith("5")) {
					recordFivelist.add(rt);
				}
			}
		}
		
		System.out.println("-------------------------------------------------------------------");
		System.out.println("-------------------------------------------------------------------");
		System.out.println("Detail Record Five");
		System.out.println("-------------------------------------------------------------------");
		System.out.println("-------------------------------------------------------------------");
		
		System.out.println(recordFivelist.size());
		for(RecordFive rec : recordFivelist) {
			System.out.println(" ChargeIndicator : "+rec.getChargeIndicator());
			System.out.println(" CustAddrone : "+rec.getCustAddrone());
			System.out.println(" CustAddrtwo : "+rec.getCustAddrtwo());
			System.out.println(" CustAddrthree : "+rec.getCustAddrthree());
			System.out.println(" CustId : "+rec.getCustId());
			System.out.println(" CustName : "+rec.getCustName());
			System.out.println(" DetailRecordId : "+rec.getDetailRecordId());
			System.out.println(" Email : "+rec.getEmail());
			System.out.println(" Filler : "+rec.getFiller());
			System.out.println(" PaymentIndicator : "+rec.getPaymentIndicator());
			System.out.println(" RecvBnkAddrone : "+rec.getRecvBnkAddrone());
			System.out.println(" RecvBnkAddrtwo : "+rec.getRecvBnkAddrtwo());
			System.out.println(" RecvBnkAddrthree : "+rec.getRecvBnkAddrthree());
			System.out.println(" RecvBnkId : "+rec.getRecvBnkId());
			System.out.println(" RecvBnkName : "+rec.getRecvBnkName());
			System.out.println(" SeqTraceNum : "+rec.getSeqTraceNum());
		}
		System.out.println("-------------------------------------------------------------------");
		
		
/* Detail Record 5*/		
		
		
/* Detail Record 6*/
		
		InputStream inputStreamSix = getClass().getClassLoader().getResourceAsStream(INPUT_TXT_RESOURCE_CLASSPATH);		
		FlatFileReaderDefinition ffDefinitionSix = new FlatFileReaderDefinition(RecordSix.class);
		ffDefinition.setHeader(Header.class);
		FlatFileReader ffReaderSix = new InputStreamFlatFileReader(inputStreamSix, ffDefinitionSix);
		
		for(Object record :  ffReaderSix) {
			RecordType recordType = ffReaderSix.getRecordType();
				if (recordType == RecordType.BODY) {
				RecordSix rt = (RecordSix)record;
				if(rt.getDetailrecordid().startsWith("6")) {
					recordSixlist.add(rt);
				}
			}
		}
		
		System.out.println("-------------------------------------------------------------------");
		System.out.println("-------------------------------------------------------------------");
		System.out.println("Detail Record Six");
		System.out.println("-------------------------------------------------------------------");
		System.out.println("-------------------------------------------------------------------");
		
		System.out.println(recordSixlist.size());
		for(RecordSix rec : recordSixlist) {
			System.out.println(" Detailrecordid : "+rec.getDetailrecordid());
			System.out.println(" Filler : "+rec.getFiller());
			System.out.println(" Record_id : "+rec.getRecord_id());
			System.out.println(" RemittanceDetail1 : "+rec.getRemittanceDetail1());
			System.out.println(" RemittanceDetail2 : "+rec.getRemittanceDetail2());
			System.out.println(" RemittanceDetail3 : "+rec.getRemittanceDetail3());
			System.out.println(" RemittanceDetail4 : "+rec.getRemittanceDetail4());
			System.out.println(" RemittanceDetail5 : "+rec.getRemittanceDetail5());
			System.out.println(" RemittanceDetail6 : "+rec.getRemittanceDetail6());
			System.out.println(" RemittanceDetail7 : "+rec.getRemittanceDetail7());
			System.out.println(" RemittanceDetail8 : "+rec.getRemittanceDetail8());
			System.out.println(" RemittanceDetail9 : "+rec.getRemittanceDetail9());
			System.out.println(" RemittanceDetail10 : "+rec.getRemittanceDetail10());
			System.out.println(" SeqTraceNum : "+rec.getSeqTraceNum());
		}
		System.out.println("-------------------------------------------------------------------");
		
		
/* Detail Record 6*/
		
/*   Trailer stub start */		
		InputStream inputStreamread = getClass().getClassLoader().getResourceAsStream(INPUT_TXT_RESOURCE_CLASSPATH);		
		FlatFileReaderDefinition ffDefinitiontrail = new FlatFileReaderDefinition(Trailer.class);
		ffDefinition.setHeader(Header.class);
		FlatFileReader ffReadertrail = new InputStreamFlatFileReader(inputStreamread, ffDefinitiontrail);
		
		Trailer lastrecord = null;
		for(Object record : ffReadertrail ) {
			Trailer tst = (Trailer)record;
			lastrecord = tst;
		}
		System.out.println("...... Trail .......");
		System.out.println(" AmtSrcCurrency : "+lastrecord.getAmtSrcCurrency());
		System.out.println(" FileLayoutVersCtrl : "+lastrecord.getFileLayoutVersCtrl());
		System.out.println(" Filler : "+lastrecord.getFiller());
		System.out.println(" NumOfpayments : "+lastrecord.getNumOfpayments());
		System.out.println(" NumOfRecords : "+lastrecord.getNumOfRecords());
		System.out.println(" RecordNum : "+lastrecord.getRecordNum());
		System.out.println(" TotalPayoutCurrency : "+lastrecord.getTotalPayoutCurrency());
		
		
		
		ffReadertrail.close();
		ffReader.close();
/*   Trailer stub end */		
	}
}
